-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2019 at 05:20 AM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `facefly`
--

-- --------------------------------------------------------

--
-- Table structure for table `airlines`
--

CREATE TABLE `airlines` (
  `airline_id` int(11) NOT NULL,
  `airline_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `airline_code` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `airlines`
--

INSERT INTO `airlines` (`airline_id`, `airline_name`, `airline_code`) VALUES
(1, 'Vietnam Airlines', 'VN'),
(2, 'VietJet Air', 'VJ'),
(3, 'Jetstar', 'BL');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_code` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_airport` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`city_id`, `city_name`, `city_code`, `city_airport`) VALUES
(1, 'Hà Nội', 'HAN', 'Sân bay quốc tế Nội Bài'),
(2, 'Hồ Chí Minh', 'SGN', 'Sân bay quốc tế Hồ Chí Minh'),
(3, 'Ban Mê Thuộc', 'BMV', 'Sân bay Ban Mê Thuộc'),
(4, 'Cà Mau', 'CAH', 'Sân bay Cà Mau');

-- --------------------------------------------------------

--
-- Table structure for table `fb_fl_exchange`
--

CREATE TABLE `fb_fl_exchange` (
  `id` int(11) NOT NULL,
  `ffe_bk_id` int(11) NOT NULL,
  `ffe_fl_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fb_fl_exchange`
--

INSERT INTO `fb_fl_exchange` (`id`, `ffe_bk_id`, `ffe_fl_id`) VALUES
(1, 10, 2),
(2, 10, 3),
(3, 11, 2),
(4, 11, 3),
(5, 12, 2),
(6, 12, 3),
(7, 13, 2),
(8, 13, 3),
(9, 14, 2),
(10, 14, 3),
(11, 15, 2),
(12, 15, 3),
(13, 16, 2),
(14, 16, 3),
(15, 17, 2),
(16, 17, 3),
(17, 18, 2),
(18, 18, 3),
(19, 19, 2),
(20, 19, 3),
(21, 20, 2),
(22, 20, 3),
(23, 21, 2),
(24, 21, 3),
(25, 22, 2),
(26, 22, 3),
(27, 23, 2),
(28, 23, 3),
(29, 24, 2),
(30, 24, 3),
(31, 25, 2),
(32, 25, 3),
(33, 26, 2),
(34, 26, 3),
(35, 27, 2),
(36, 27, 3),
(37, 28, 2),
(38, 28, 3),
(39, 29, 2),
(40, 29, 3),
(41, 30, 2),
(42, 30, 3),
(43, 31, 2),
(44, 31, 3),
(45, 32, 2),
(46, 32, 3),
(47, 33, 1),
(48, 34, 2),
(49, 34, 3),
(50, 35, 2),
(51, 35, 3),
(52, 36, 1),
(53, 37, 1),
(54, 38, 1),
(55, 39, 1),
(56, 40, 1);

-- --------------------------------------------------------

--
-- Table structure for table `flight_booking`
--

CREATE TABLE `flight_booking` (
  `fb_id` int(11) NOT NULL,
  `fb_city_id_from` int(11) NOT NULL,
  `fb_city_id_to` int(11) NOT NULL,
  `fb_departure_date` int(11) NOT NULL,
  `fb_type` tinyint(4) NOT NULL,
  `fb_return_date` int(11) DEFAULT NULL,
  `fb_users_id` int(11) NOT NULL,
  `fb_bfe_fl_id` int(11) DEFAULT NULL,
  `fb_transfer` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_paypal` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_credit_card` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_credit_name` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_ccv_code` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flight_booking`
--

INSERT INTO `flight_booking` (`fb_id`, `fb_city_id_from`, `fb_city_id_to`, `fb_departure_date`, `fb_type`, `fb_return_date`, `fb_users_id`, `fb_bfe_fl_id`, `fb_transfer`, `fb_paypal`, `fb_credit_card`, `fb_credit_name`, `fb_ccv_code`) VALUES
(40, 1, 2, 1551762000, 1, NULL, 22, NULL, NULL, NULL, '', '', ''),
(39, 1, 2, 1551762000, 1, NULL, 22, NULL, NULL, NULL, '', '', ''),
(38, 1, 2, 1551762000, 1, NULL, 22, NULL, NULL, NULL, '', '', ''),
(37, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(36, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(35, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(34, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(33, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(32, 1, 2, 1551762000, 1, NULL, 22, NULL, 'YES', NULL, NULL, NULL, NULL),
(31, 1, 2, 1551762000, 1, NULL, 22, NULL, NULL, NULL, '11111111111', 'Tran Due', '315'),
(30, 1, 2, 1551762000, 1, NULL, 22, NULL, NULL, NULL, '11111111111', 'Tran Due', '315'),
(29, 1, 2, 1551762000, 1, NULL, 21, NULL, 'YES', NULL, NULL, NULL, NULL),
(28, 1, 2, 1551762000, 1, NULL, 21, NULL, 'YES', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `flight_class`
--

CREATE TABLE `flight_class` (
  `fc_id` int(11) NOT NULL,
  `fc_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flight_class`
--

INSERT INTO `flight_class` (`fc_id`, `fc_name`) VALUES
(1, 'Economy Flex'),
(2, 'Economy Standard'),
(3, 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `flight_list`
--

CREATE TABLE `flight_list` (
  `fl_id` int(11) NOT NULL,
  `fl_airline_id` int(11) NOT NULL,
  `fl_departure_date` int(11) NOT NULL,
  `fl_landing_date` int(11) NOT NULL,
  `fl_city_id_from` int(11) NOT NULL,
  `fl_city_id_to` int(11) NOT NULL,
  `fl_id_parent` int(11) NOT NULL,
  `fl_cost` float NOT NULL,
  `fl_fc_id` int(11) NOT NULL,
  `fl_seat` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flight_list`
--

INSERT INTO `flight_list` (`fl_id`, `fl_airline_id`, `fl_departure_date`, `fl_landing_date`, `fl_city_id_from`, `fl_city_id_to`, `fl_id_parent`, `fl_cost`, `fl_fc_id`, `fl_seat`) VALUES
(1, 1, 1551762000, 1551765600, 1, 2, 0, 500000, 1, 100),
(2, 1, 1551762000, 1551763500, 1, 3, 1, 500000, 1, 100),
(3, 1, 1551767400, 1551769200, 3, 2, 1, 200000, 1, 11),
(4, 1, 1551767400, 1551769200, 4, 2, 0, 300000, 1, 11),
(5, 1, 1551769200, 1551769200, 2, 1, 0, 600000, 1, 100),
(6, 2, 1551769200, 1551769200, 2, 3, 5, 600000, 1, 100),
(7, 1, 1551769200, 1551769200, 3, 4, 5, 600000, 1, 100),
(8, 3, 1551769200, 1551769200, 4, 1, 5, 600000, 1, 100),
(9, 2, 1551769200, 1551769200, 2, 1, 0, 600000, 1, 100);

-- --------------------------------------------------------

--
-- Table structure for table `passengers`
--

CREATE TABLE `passengers` (
  `passenger_id` int(11) NOT NULL,
  `passenger_title` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passenger_first_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passenger_last_name` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passenger_user_id` int(11) NOT NULL,
  `passenger_bk_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `passengers`
--

INSERT INTO `passengers` (`passenger_id`, `passenger_title`, `passenger_first_name`, `passenger_last_name`, `passenger_user_id`, `passenger_bk_id`) VALUES
(15, 'mr', 'HO VAN QUYEN', 'HO VAN QUYEN', 22, 35),
(14, 'mr', '', '', 22, 34),
(13, 'mr', 'Tran', 'Anh', 22, 33),
(12, 'mr', 'Ho', 'Quyen', 22, 32),
(11, 'mrs', 'Nguyen', 'Hien', 22, 31),
(10, 'mr', 'Tran', 'Due', 22, 30),
(16, 'mr', '123123', '123123', 22, 36),
(17, 'mr', 'AAAAA', '23123123', 22, 37),
(18, 'mr', 'AAAAA', 'AAAA', 22, 38),
(19, 'mr', 'AAAA', 'AAAA', 22, 39),
(20, 'mr', 'AAA', 'AAA', 22, 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `fail_login` int(11) NOT NULL,
  `last_access` timestamp(6) NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `remember_token`, `fail_login`, `last_access`, `created_at`, `updated_at`) VALUES
(13, 'Củ chuối', 'hhh@gmail.com', '123123', '$2y$10$nSpPNqxpnKAOquSYnD0ShOxeV8SMbZkYfzSptMj5r.e1D2wDp7Ba6', 'o3m0DS74ZaQ4OrBWnilM226WQtGOsSsvFCyYui743ruv2G8RN8PbeW84vjxW', 1, '2019-03-06 01:54:33.000000', '2019-02-26 06:10:57', '2019-03-05 18:24:33'),
(21, 'Tran Thi Hoa', 'tranthihoa111@gmail.com', '123123123123', '$2y$10$JFvrZJRAyJXG9oKO3PtuT.5tHR.5brSVupbXMah8VytPSpfaQaO9C', 'OHsjubm8fc3YQ6OyeDEiBYELCsxKS8RHShzHdQfRYuCmadUlDOAxlann5EbN', 0, '2019-03-05 16:26:30.000000', '2019-03-05 08:51:56', '2019-03-05 09:13:24'),
(22, 'HO VAN QUYEN', 'quyenho1368@gmail.com', '0962953150', '$2y$10$j0NGhKasmotLPpuTqvpB1.A6usKZWIew9/wSajvyce/aX1Xe/LimS', 'yVeHZGnyIVA1QNeHtY2V9cRUaGJGsRcA4SDlDTXKUd2zvBLNDbQm4Rl5Nvde', 0, '2019-03-11 17:34:13.000000', '2019-03-06 08:46:28', '2019-03-11 20:00:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airlines`
--
ALTER TABLE `airlines`
  ADD PRIMARY KEY (`airline_id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`city_id`);

--
-- Indexes for table `fb_fl_exchange`
--
ALTER TABLE `fb_fl_exchange`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flight_booking`
--
ALTER TABLE `flight_booking`
  ADD PRIMARY KEY (`fb_id`);

--
-- Indexes for table `flight_class`
--
ALTER TABLE `flight_class`
  ADD PRIMARY KEY (`fc_id`);

--
-- Indexes for table `flight_list`
--
ALTER TABLE `flight_list`
  ADD PRIMARY KEY (`fl_id`);

--
-- Indexes for table `passengers`
--
ALTER TABLE `passengers`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `airlines`
--
ALTER TABLE `airlines`
  MODIFY `airline_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `city_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `fb_fl_exchange`
--
ALTER TABLE `fb_fl_exchange`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `flight_booking`
--
ALTER TABLE `flight_booking`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `flight_class`
--
ALTER TABLE `flight_class`
  MODIFY `fc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `flight_list`
--
ALTER TABLE `flight_list`
  MODIFY `fl_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `passengers`
--
ALTER TABLE `passengers`
  MODIFY `passenger_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
