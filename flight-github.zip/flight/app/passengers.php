<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class passengers extends Model {

	//
		protected $table = "passengers";
	public $primaryKey = "passenger_id";
	public $timestamps = false;


}

