<?php

namespace App;

class Book {
	public $id_parant = 0;
	public $number_transit = 0;
	function add($id_parant, $number_transit) {

	}
}