<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class flight_booking extends Model {

	//
	protected $table = "flight_booking";
	public $primaryKey = "fb_id";
	public $timestamps = false;
}
