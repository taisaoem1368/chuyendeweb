<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class cities extends Model {

	//
	protected $table = "cities";
	public $primaryKey = "city_id";
	public $timestamps = false;

}
