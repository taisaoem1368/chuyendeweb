<?php namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\cities;
use Session;
class DataProvider extends ServiceProvider {

	/**
	 * Bootstrap the application services.
	 *
	 * @return void
	 */
	public function boot()
	{

		view()->composer('*', function($view){
			$cities = cities::all();
			return $view->with('cities', $cities);
		});
		view()->composer(['flight-book', 'flight-list', 'flight-detail'], function($view) {	
			if(Session::has('booking_choose'))
			{
				$booking_choose = Session::get('booking_choose');
				return $view->with(['booking_choose' => $booking_choose]);
			}
		});
	}


	/**
	 * Register the application services.
	 *
	 * @return void
	 */
	public function register()
	{
		//
	}

}
