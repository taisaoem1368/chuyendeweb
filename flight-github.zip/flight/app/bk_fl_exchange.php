<?php namespace App;

use Illuminate\Database\Eloquent\Model;

class bk_fl_exchange extends Model {

	//
	protected $table = "fb_fl_exchange";
	public $primaryKey = "ffe_id";
	public $timestamps = false;

}
