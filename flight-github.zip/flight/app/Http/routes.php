<?php
use App\DSDiaDiemModel;
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/



//===================>Search- Flights
Route::get('/flight-detail', ['as' => 'xemChiTiet', 'uses' => 'UserController@xemChiTiet']);

Route::get('/search-flights', ['as' => 'timChuyenBay', 'uses' => 'UserController@timChuyenBay']);

Route::get('/flight-book', ['as' => 'Booking', 'middleware' => 'checkAuth', 'uses' => 'UserController@booking']);
Route::post('/continue-to-booking', ['as' => 'datVe', 'middleware' => 'checkAuth', 'uses' => 'UserController@datve']);

//==================> User
Route::get('/update-information-user',['as' => 'update-user', 'middleware' => 'checkAuth', 'uses' => 'UserController@getUpdateUser']);
Route::post('/update-information-user/{id}', ['as' => 'update-user', 'uses' => 'UserController@postUpdateUser']);
Route::post('/quenpass', ['as' => 'verify', 'uses' => 'UserController@verify']);
Route::get('/verify/token/{id}', ['as' => 'laylaipass', 'uses' => 'UserController@getLaylaipass']);
Route::post('/verify/token/{id}', ['as' => 'laylaipass', 'uses' => 'UserController@postLaylaipass']);
Route::get('/verify', function(){ $dsdiadiem = DSDiaDiemModel::all(); return view('index', ['dsdiadiem' => $dsdiadiem]);});
//=======================================================================
Route::get('/register', ['as' => 'getRegister', 'uses' =>'Auth\AuthController@getRegister']);
Route::post('/register', ['as' => 'postRegister', 'uses' => 'Auth\AuthController@postRegister']);
Route::get('/login', ['as' => 'getLogin', 'uses' => 'Auth\AuthController@getLogin']);
Route::post('/login', ['as' => 'postLogin', 'uses' => 'Auth\AuthController@postLogin']);
Route::controllers([
	'auth' => 'Auth\AuthController',
	'password' => 'Auth\PasswordController',
]);
Route::get('/{id?}', 'UserController@index');